import java.util.List;

class ListNode {
int val;
ListNode next;

ListNode() {}
ListNode(int val) {
    this.val = val;
}
ListNode(int val, ListNode next) {
    this.val = val;
    this.next = next;
}

}

class Solution {
private static class Split {
ListNode smallStart, smallEnd;
ListNode largeStart, largeEnd;
}

public ListNode partition(ListNode head, int x) {
    if (head == null) {
        return null;
    }
    Split result = divide(head, x);
    if (result.largeEnd != null) {
        result.largeEnd.next = null;
    }
    if (result.smallStart == null) {
        return result.largeStart;
    }
    result.smallEnd.next = result.largeStart;
    return result.smallStart;
}
private Split divide(ListNode head, int x) {
    if (head.next == null) {
        Split part = new Split();
        if (head.val < x) {
            part.smallStart = part.smallEnd = head;
        } else {
            part.largeStart = part.largeEnd = head;
        }
        return part;
    }
    ListNode first = head;
    ListNode second = head.next;
    while (second != null && second.next != null) {
        first = first.next;
        second = second.next.next;
    }
    ListNode otherHalf = first.next;
    first.next = null;
    Split leftPart = divide(head, x);
    Split rightPart = divide(otherHalf, x);
    return combine(leftPart, rightPart);
}
private Split combine(Split leftPart, Split rightPart) {
    if (leftPart.smallEnd == null) {
        leftPart.smallStart = rightPart.smallStart;
        leftPart.smallEnd = rightPart.smallEnd;
    } else if (rightPart.smallStart != null) {
        leftPart.smallEnd.next = rightPart.smallStart;
        leftPart.smallEnd = rightPart.smallEnd;
    }
    if (leftPart.largeEnd == null) {
        leftPart.largeStart = rightPart.largeStart;
        leftPart.largeEnd = rightPart.largeEnd;
    } else if (rightPart.largeStart != null) {
        leftPart.largeEnd.next = rightPart.largeStart;
        leftPart.largeEnd = rightPart.largeEnd;
    }
    return leftPart;
}

}